package org.mddarr.driversservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DriversServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DriversServiceApplication.class, args);
	}

}
