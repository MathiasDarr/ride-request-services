package org.mddarr.driversservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriversServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
